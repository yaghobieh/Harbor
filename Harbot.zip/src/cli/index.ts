#!/usr/bin/env node

import { resolve } from 'path';
import { existsSync, writeFileSync, mkdirSync } from 'fs';
import { createLogger } from '../utils/logger';

const logger = createLogger('cli');

interface CliCommand {
  name: string;
  description: string;
  action: (args: string[]) => Promise<void> | void;
}

const commands: CliCommand[] = [
  {
    name: 'init',
    description: 'Initialize a new Harbor project',
    action: initProject,
  },
  {
    name: 'generate',
    description: 'Generate server file from config',
    action: generateServer,
  },
  {
    name: 'docs',
    description: 'Generate API documentation',
    action: generateDocs,
  },
  {
    name: 'version',
    description: 'Show Harbor version',
    action: showVersion,
  },
  {
    name: 'help',
    description: 'Show help information',
    action: showHelp,
  },
];

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  const commandName = args[0] ?? 'help';
  const commandArgs = args.slice(1);

  const command = commands.find((c) => c.name === commandName);

  if (!command) {
    console.error(`Unknown command: ${commandName}`);
    showHelp();
    process.exit(1);
  }

  try {
    await command.action(commandArgs);
  } catch (error) {
    logger.error('Command failed', error as Error);
    process.exit(1);
  }
}

function initProject(): void {
  const cwd = process.cwd();
  
  const configPath = resolve(cwd, 'harbor.config.json');
  if (existsSync(configPath)) {
    console.log('harbor.config.json already exists');
    return;
  }

  const defaultConfig = {
    server: {
      port: 3000,
      host: 'localhost',
      cors: {
        enabled: true,
        origin: '*',
      },
      bodyParser: {
        json: true,
        urlencoded: true,
        limit: '10mb',
      },
    },
    routes: {
      prefix: '/api',
      timeout: 30000,
    },
    validation: {
      adapter: 'mongoose',
      strictMode: true,
      sanitize: true,
    },
    errors: {
      404: {
        message: 'Not Found',
        json: true,
      },
      500: {
        message: 'Internal Server Error',
        json: true,
        log: true,
      },
    },
    logger: {
      enabled: true,
      level: 'info',
      format: 'text',
      output: 'console',
    },
  };

  writeFileSync(configPath, JSON.stringify(defaultConfig, null, 2), 'utf-8');
  console.log('Created harbor.config.json');

  const serverDir = resolve(cwd, 'src');
  if (!existsSync(serverDir)) {
    mkdirSync(serverDir, { recursive: true });
  }

  const serverPath = resolve(serverDir, 'server.ts');
  if (!existsSync(serverPath)) {
    const serverTemplate = `import { createServer, RouteBuilder } from 'harbor';

const server = createServer({
  port: 3000,
  autoStart: false,
});

// Define your routes
const healthRoute = RouteBuilder.create()
  .get('/health')
  .handler(() => ({ status: 'ok', timestamp: new Date().toISOString() }))
  .build();

server.addRoute(healthRoute);

// Start the server
server.start().then((info) => {
  console.log(\`Server running at http://\${info.host}:\${info.port}\`);
});
`;

    writeFileSync(serverPath, serverTemplate, 'utf-8');
    console.log('Created src/server.ts');
  }

  console.log('\nHarbor project initialized!');
  console.log('Run: npm install harbor');
  console.log('Then: npx ts-node src/server.ts');
}

function generateServer(): void {
  console.log('Generating server from config...');
  console.log('This feature is coming soon!');
}

function generateDocs(): void {
  console.log('Generating API documentation...');
  console.log('This feature is coming soon!');
}

function showVersion(): void {
  console.log('Harbor v1.0.0');
}

function showHelp(): void {
  console.log('\nHarbor - The pipeline for Node.js backends\n');
  console.log('Usage: harbor <command> [options]\n');
  console.log('Commands:\n');

  for (const command of commands) {
    console.log(`  ${command.name.padEnd(12)} ${command.description}`);
  }

  console.log('\nExamples:\n');
  console.log('  harbor init          Initialize a new project');
  console.log('  harbor docs          Generate API documentation');
  console.log('  harbor version       Show version');
}

main();

